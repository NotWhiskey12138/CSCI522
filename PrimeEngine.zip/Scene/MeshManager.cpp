// API Abstraction
#include "PrimeEngine/APIAbstraction/APIAbstractionDefines.h"

#include "MeshManager.h"
// Outer-Engine includes

// Inter-Engine includes
#include "PrimeEngine/FileSystem/FileReader.h"
#include "PrimeEngine/APIAbstraction/GPUMaterial/GPUMaterialSet.h"
#include "PrimeEngine/PrimitiveTypes/PrimitiveTypes.h"
#include "PrimeEngine/APIAbstraction/Texture/Texture.h"
#include "PrimeEngine/APIAbstraction/Effect/EffectManager.h"
#include "PrimeEngine/APIAbstraction/GPUBuffers/VertexBufferGPUManager.h"
#include "PrimeEngine/../../GlobalConfig/GlobalConfig.h"

#include "PrimeEngine/Geometry/SkeletonCPU/SkeletonCPU.h"

#include "PrimeEngine/Scene/RootSceneNode.h"

#include "Light.h"

// Sibling/Children includes

#include "MeshInstance.h"
#include "Skeleton.h"
#include "SceneNode.h"
#include "DrawList.h"
#include "SH_DRAW.h"
#include "PrimeEngine/Lua/LuaEnvironment.h"

#include "cfloat"

namespace PE {
	namespace Components {

		PE_IMPLEMENT_CLASS1(MeshManager, Component);
		MeshManager::MeshManager(PE::GameContext& context, PE::MemoryArena arena, Handle hMyself)
			: Component(context, arena, hMyself)
			, m_assets(context, arena, 256)
		{
		}

		PE::Handle MeshManager::getAsset(const char* asset, const char* package, int& threadOwnershipMask)
		{
			char key[StrTPair<Handle>::StrSize];
			sprintf(key, "%s/%s", package, asset);

			int index = m_assets.findIndex(key);
			if (index != -1)
			{
				return m_assets.m_pairs[index].m_value;
			}
			Handle h;

			if (StringOps::endswith(asset, "skela"))
			{
				PE::Handle hSkeleton("Skeleton", sizeof(Skeleton));
				Skeleton* pSkeleton = new(hSkeleton) Skeleton(*m_pContext, m_arena, hSkeleton);
				pSkeleton->addDefaultComponents();

				pSkeleton->initFromFiles(asset, package, threadOwnershipMask);
				h = hSkeleton;
			}
			else if (StringOps::endswith(asset, "mesha"))
			{
				MeshCPU mcpu(*m_pContext, m_arena);
				mcpu.ReadMesh(asset, package, "");

				PE::Handle hMesh("Mesh", sizeof(Mesh));
				Mesh* pMesh = new(hMesh) Mesh(*m_pContext, m_arena, hMesh);
				pMesh->addDefaultComponents();

				pMesh->loadFromMeshCPU_needsRC(mcpu, threadOwnershipMask);

				int numVertices = mcpu.m_hPositionBufferCPU.getObject<PositionBufferCPU>()->m_values.m_size;
				Vector3 minBounds(FLT_MAX, FLT_MAX, FLT_MAX);
				Vector3 maxBounds(-FLT_MAX, -FLT_MAX, -FLT_MAX);




				for (int i = 0; i < numVertices / 3; ++i) {
					int index = i * 3;
					Vector3 vertex(
						mcpu.m_hPositionBufferCPU.getObject<PositionBufferCPU>()->m_values[index],
						mcpu.m_hPositionBufferCPU.getObject<PositionBufferCPU>()->m_values[index + 1],
						mcpu.m_hPositionBufferCPU.getObject<PositionBufferCPU>()->m_values[index + 2]
					);


					/*Vector3 transformedVertex = worldTransform * vertex;*/

					if (vertex.m_x < minBounds.m_x) minBounds.m_x = vertex.m_x;
					if (vertex.m_y < minBounds.m_y) minBounds.m_y = vertex.m_y;
					if (vertex.m_z < minBounds.m_z) minBounds.m_z = vertex.m_z;

					if (vertex.m_x > maxBounds.m_x) maxBounds.m_x = vertex.m_x;
					if (vertex.m_y > maxBounds.m_y) maxBounds.m_y = vertex.m_y;
					if (vertex.m_z > maxBounds.m_z) maxBounds.m_z = vertex.m_z;
				}

				//Vector3 aabbCorners[8] = {
			 //   Vector3(minBounds.m_x, minBounds.m_y, minBounds.m_z), // 1
			 //   Vector3(minBounds.m_x, minBounds.m_y, maxBounds.m_z), // 2
			 //   Vector3(minBounds.m_x, maxBounds.m_y, minBounds.m_z), // 3
			 //   Vector3(minBounds.m_x, maxBounds.m_y, maxBounds.m_z), // 4
			 //   Vector3(maxBounds.m_x, minBounds.m_y, minBounds.m_z), // 5
			 //   Vector3(maxBounds.m_x, minBounds.m_y, maxBounds.m_z), // 6
			 //   Vector3(maxBounds.m_x, maxBounds.m_y, minBounds.m_z), // 7
			 //   Vector3(maxBounds.m_x, maxBounds.m_y, maxBounds.m_z)  // 8
				//};

				// saving minBounds and maxBounds to Mesh class
				pMesh->m_minBounds = minBounds;
				pMesh->m_maxBounds = maxBounds;

#if PE_API_IS_D3D11
				// todo: work out how lods will work
				//scpu.buildLod();
#endif
		// generate collision volume here. or you could generate it in MeshCPU::ReadMesh()
				pMesh->m_performBoundingVolumeCulling = true; // will now perform tests for this mesh

				h = hMesh;
			}


			PEASSERT(h.isValid(), "Something must need to be loaded here");

			RootSceneNode::Instance()->addComponent(h);
			m_assets.add(key, h);
			return h;
		}

		void MeshManager::registerAsset(const PE::Handle& h)
		{
			static int uniqueId = 0;
			++uniqueId;
			char key[StrTPair<Handle>::StrSize];
			sprintf(key, "__generated_%d", uniqueId);

			int index = m_assets.findIndex(key);
			PEASSERT(index == -1, "Generated meshes have to be unique");

			RootSceneNode::Instance()->addComponent(h);
			m_assets.add(key, h);
		}

	}; // namespace Components
}; // namespace PE
